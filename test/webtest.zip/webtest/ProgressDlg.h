#pragma once
#include "afxcmn.h"

#include "Resource.h"
#include "TextProgressCtrl.h"
#include "afxwin.h"
#include "Global.h"
// CProgressDlg ��ȭ �����Դϴ�.


class CProgressDlg : public CDialog
{
	DECLARE_DYNAMIC(CProgressDlg)

public:
	CProgressDlg(CWnd* pParent = NULL);   // ǥ�� �������Դϴ�.
	virtual ~CProgressDlg();

// ��ȭ ���� �������Դϴ�.
	enum { IDD = IDD_PROGRESS_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �����Դϴ�.

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	CTextProgressCtrl m_ProgressCtrl;
	CBrush m_GroupStaticBrush;
	//CBrush m_BGStaticBrush;

	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	CStatic m_StateStaticCtrl;
	CStatic m_SubStateStaticCtrl;
	CString m_StateStatic;
	CString m_SubStateStatic;
	VOID SetState(IN CString strState, IN CString strSubState);
	VOID Exit(); // â �ݱ�
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
};
