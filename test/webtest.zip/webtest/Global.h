#include <strsafe.h>
#include <CommCtrl.h>
#include <iostream>
#include <map>

#include "Util.h"
#include "Log.h"
////////////////////////////////////////////////////////////////
// DEFINES
////////////////////////////////////////////////////////////////
extern CRITICAL_SECTION WriteLogLock;
extern WCHAR gHomeDirPath[MAX_OBJ_PATH_W];

#define WIDEN2(x) L ## x
#define WIDEN(x) WIDEN2(x)
#define __WFILE__ WIDEN(__FILE__)

// �α� ���� �̸� : Log.cpp
#define _DOC_LOG_FILE_NAME_1				L"doc_api_1.log"
#define _DOC_LOG_FILE_NAME_2				L"doc_api_2.log"

// html ��°���
#define USER_PROFILE_PATH  _T("D:\\chrome")		// ������ userprofile ���
#define BROWSER_PATH	   _T("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe")	// ũ�Һ����� ���
#define WEB_WIDTH  700	// ������ ����
#define WEB_HEIGHT 600	// ������ ����


// �׷� ������ƽ ����
#define GROUP_STATIC_BACKGOUND_COLOR RGB(230, 230, 230)
#define BG_STATIC_BACKGOUND_COLOR RGB(255, 255, 255)
#define NEOPC_PROGRESS_BAR_TITLE_NAME					_T("-Mpower EZis-C ProgressBar-")

#define TITLE_TEXT _T("MoADM")
////////////////////////////////////////////////////////////////
// TYPEDEFES
////////////////////////////////////////////////////////////////
#pragma pack(1)

#pragma pack()

////////////////////////////////////////////////////////////////
// VARIABLES
////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////
// FUNCTIONS
////////////////////////////////////////////////////////////////

