﻿
// webtestDlg.cpp : 구현 파일
//

#include "stdafx.h"
#include "webtest.h"
#include "webtestDlg.h"
#include "afxdialogex.h"

#include "Global.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

HANDLE MonitoringFileKillEvent = NULL;
HANDLE hMonitroingFileThread = NULL;
HANDLE m_hDirectory = NULL;
BOOLEAN m_stopMonitoring = FALSE;

static int CALLBACK BrowseCallbackProc(HWND hwnd, UINT uMsg, LPARAM lParam, LPARAM lpData)
{
	WCHAR Text[MAX_PATH] = {0, };
	BOOL bReturn = FALSE;
	CString strMsg;

	switch(uMsg)
	{
	case BFFM_INITIALIZED:	// 초기화시 호출
		{
			//////////////////////////////////////////////////////////////////
			// SHBrowseForFolder 컨트롤 ID 종류
			//
			// HWND hShell = GetDlgItem(hwnd, 0);		// 0x00000000(Shell Class)
			// HWND hTree = GetDlgItem(hShell, 100);	// 0x00000064(Tree Control)
			// HWND hNew = GetDlgItem(hwnd, 14150);		// 0x00003746(New Folder Button)
			// HWND hOK = GetDlgItem(hwnd, 1);			// 0x00000001(OK Button)
			// HWND hCancel= GetDlgItem(hwnd, 2);		// 0x00000002(Cancel Button)
			// HWND hStatic= GetDlgItem(hwnd, 14146);	// 0x00003742(Static Control)
			//////////////////////////////////////////////////////////////////

			// 새로 만들기 버튼은 숨김
			// 			HWND hNewButton = GetDlgItem(hwnd, 14150);
			// 			if(hNewButton!= NULL)
			// 			{
			// 				ShowWindow(hNewButton, SW_HIDE);
			// 			}

			SendMessage(hwnd, BFFM_SETSELECTION, TRUE, (LPARAM)lpData);
			SendMessage(hwnd, BFFM_SETOKTEXT, TRUE, (LPARAM)L"확인");

			// [bong][2020-05-13] 폴더 찾아보기 캡션 변경
			if(hwnd!= NULL)
			{
				SetWindowTextW(hwnd, L"폴더 찾아보기");
			}

			// [bong][2019-11-06] 취소버튼
			HWND hCancelButton = GetDlgItem(hwnd, 2);
			if(hCancelButton!= NULL)
			{
				SetWindowTextW(hCancelButton, L"취소");
			}

			// [bong][2019-11-06] 새로 만들기 버튼
			HWND hNewButton = GetDlgItem(hwnd, 14150);
			if(hNewButton!= NULL)
			{
				SetWindowTextW(hNewButton, L"새 폴더 만들기(A)");
			}

			break;
		}
	case BFFM_SELCHANGED:
		{
			bReturn = SHGetPathFromIDList((ITEMIDLIST*)lParam, Text);
			if(bReturn == TRUE)
			{
				strMsg.Format(L"경로 : %s", Text);

				HWND hTitleControl = GetDlgItem(hwnd, 14146); // Title 컨트롤 
				if(hTitleControl != NULL)
				{
					::SetWindowTextW(hTitleControl, strMsg);
				}

				//SendMessage(hwnd, BFFM_SETSTATUSTEXT, 0, (LPARAM)Text); 
			}
			break;
		}
	}

	return 0;
}



// 응용 프로그램 정보에 사용되는 CAboutDlg 대화 상자입니다.

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 대화 상자 데이터입니다.
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

// 구현입니다.
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CwebtestDlg 대화 상자

CwebtestDlg::CwebtestDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(CwebtestDlg::IDD, pParent)
	, m_bOut_Web(TRUE)
	, m_FolderPath(_T("H:\내 폴더\문서"))
	, m_GroupFolderPath(_T("H:\내 폴더\인공지능\테스트문서\문서검색"))
	, m_strServerIP(_T("10.10.4.10"))
	, m_strServerPort(_T("9003"))
	, m_strESIndexName(_T("mpower10u_vector"))
	, m_strSearchK(_T("5"))
	, m_strSearchMethod(_T("백터+BM25"))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CwebtestDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_FOLDER_EDIT, m_FolderPath);
	DDX_Check(pDX, IDC_OUT_WEB_CHECK, m_bOut_Web);
	DDX_Text(pDX, IDC_FOLDER_EDIT2, m_GroupFolderPath);
	DDX_Control(pDX, IDC_MONITORING_LIST, m_MonitorViewList);
	DDX_Text(pDX, IDC_IP_EDIT, m_strServerIP);
	DDX_Text(pDX, IDC_PORT_EDIT, m_strServerPort);
	DDX_Text(pDX, IDC_ES_INDEX_EDIT, m_strESIndexName);
	DDX_CBString(pDX, IDC_SEARCH_K_COMBO, m_strSearchK);
	DDX_CBString(pDX, IDC_SEARCH_METHOD_COMBO, m_strSearchMethod);
	DDX_Control(pDX, IDC_SEARCH_METHOD_COMBO, m_searchMethodCombo);
}

BEGIN_MESSAGE_MAP(CwebtestDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_FOLDER_SELECT_BTN, &CwebtestDlg::OnBnClickedFolderSelectBtn)
	ON_BN_CLICKED(IDC_START_BTN, &CwebtestDlg::OnBnClickedStartBtn)
	ON_BN_CLICKED(IDC_STOP_BTN, &CwebtestDlg::OnBnClickedStopBtn)
	ON_WM_CLOSE()
	ON_BN_CLICKED(IDC_OUT_WEB_CHECK, &CwebtestDlg::OnBnClickedOutWebCheck)
	ON_BN_CLICKED(IDC_FOLDER_SELECT_BTN2, &CwebtestDlg::OnBnClickedFolderSelectBtn2)
	ON_BN_CLICKED(IDC_INIT_LIST_BTN, &CwebtestDlg::OnBnClickedInitListBtn)
END_MESSAGE_MAP()


// CwebtestDlg 메시지 처리기

BOOL CwebtestDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 시스템 메뉴에 "정보..." 메뉴 항목을 추가합니다.

	// IDM_ABOUTBOX는 시스템 명령 범위에 있어야 합니다.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 이 대화 상자의 아이콘을 설정합니다. 응용 프로그램의 주 창이 대화 상자가 아닐 경우에는
	//  프레임워크가 이 작업을 자동으로 수행합니다.
	SetIcon(m_hIcon, TRUE);			// 큰 아이콘을 설정합니다.
	SetIcon(m_hIcon, FALSE);		// 작은 아이콘을 설정합니다.

	// TODO: 여기에 추가 초기화 작업을 추가합니다.
	ZeroMemory(gHomeDirPath, sizeof(gHomeDirPath));
	GetCurrentDirectory(MAX_PATH, gHomeDirPath);

	InitializeCriticalSection(&WriteLogLock);

	// 프로그래스바 생성
	ProgressCreate();	

	m_searchMethodCombo.SetCurSel(1);

	// 검색목록 리스트 컨트롤 초기화
	ListView_SetExtendedListViewStyle(m_MonitorViewList.m_hWnd, LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES);
	m_MonitorViewList.InsertColumn(0, _T("no"), LVCFMT_CENTER, 60);
	m_MonitorViewList.InsertColumn(1, _T("파일"), LVCFMT_LEFT, 550);
	m_MonitorViewList.InsertColumn(2, _T("분류폴더"), LVCFMT_LEFT, 550);
	m_MonitorViewList.InsertColumn(3, _T("스코어"), LVCFMT_LEFT, 80);
	m_MonitorViewList.InsertColumn(4, _T("시간"), LVCFMT_LEFT, 80);

	return TRUE;  // 포커스를 컨트롤에 설정하지 않으면 TRUE를 반환합니다.
}

void CwebtestDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 대화 상자에 최소화 단추를 추가할 경우 아이콘을 그리려면
//  아래 코드가 필요합니다. 문서/뷰 모델을 사용하는 MFC 응용 프로그램의 경우에는
//  프레임워크에서 이 작업을 자동으로 수행합니다.

void CwebtestDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 클라이언트 사각형에서 아이콘을 가운데에 맞춥니다.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 아이콘을 그립니다.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// 사용자가 최소화된 창을 끄는 동안에 커서가 표시되도록 시스템에서
//  이 함수를 호출합니다.
HCURSOR CwebtestDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CwebtestDlg::InsertItemInList(CListCtrl *pListCtrl, 
									int nItem, 
									int nSubItem, 
									LPCTSTR Text)
{
	if(nSubItem == 0)
	{
		pListCtrl->InsertItem(nItem, Text);
	}
	else
	{
		pListCtrl->SetItemText(nItem, nSubItem, Text);
	}
}

//#include <atlstr.h> // CString 클래스 사용을 위한 헤더
//#include <iostream>
//#include <windows.h> // CreateFile, WriteFile, CloseHandle 사용을 위한 헤더



// 모니터링 폴더 경로 설정
void CwebtestDlg::OnBnClickedFolderSelectBtn()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	DWORD Status = ERROR_SUCCESS;
	BROWSEINFO BrowseInfo;
	LPITEMIDLIST pItemIdList = NULL;

	//'컴퓨터' 의 IDLIST 얻기
	LPITEMIDLIST pComputerIdList = NULL;
	SHGetSpecialFolderLocation(NULL, CSIDL_DRIVES , &pComputerIdList);
	WCHAR LocalVirtualDiskRegionPath[MAX_PATH] = {0,};

	ZeroMemory(&BrowseInfo, sizeof(BROWSEINFO));
	BrowseInfo.hwndOwner = NULL; //m_hWnd;
	BrowseInfo.pidlRoot = pComputerIdList;
	BrowseInfo.pszDisplayName = LocalVirtualDiskRegionPath;
	BrowseInfo.lpszTitle = _T("모니터링할 폴더를 지정해 주십시오.");
	BrowseInfo.ulFlags = BIF_NEWDIALOGSTYLE;
	BrowseInfo.lpfn = BrowseCallbackProc;
	BrowseInfo.lParam = (LPARAM)(LPTSTR)(LPCTSTR)m_FolderPath;

	pItemIdList = ::SHBrowseForFolder(&BrowseInfo);
	if(pItemIdList == NULL)
	{
		if(pComputerIdList != NULL)CoTaskMemFree(pComputerIdList);
		return;
	}

	if(pComputerIdList != NULL)CoTaskMemFree(pComputerIdList);

	SHGetPathFromIDList(pItemIdList, LocalVirtualDiskRegionPath);

	m_FolderPath = LocalVirtualDiskRegionPath;

	// [bong][2019-11-06] 끝에 \ 가 있으면 삭제
	if(m_FolderPath[m_FolderPath.GetLength() - 1] == '\\')
	{
		m_FolderPath.SetAt(m_FolderPath.GetLength() - 1, '\0');
	}

	UpdateData(FALSE);
}


DWORD 
WINAPI 
MonitroingFileThread(IN LPVOID Context)
{
	CString strFolderPath = _T("");
	DWORD Status = ERROR_SUCCESS;
	CwebtestDlg* pFolderMonitorDlg = (CwebtestDlg*)Context;

	//pFolderMonitorDlg->UpdateData(TRUE);
	
	strFolderPath.Format(_T("%s"), pFolderMonitorDlg->m_FolderPath);

	m_hDirectory = CreateFile(
		strFolderPath,
		FILE_LIST_DIRECTORY,
		FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
		NULL,
		OPEN_EXISTING,
		FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OVERLAPPED,
		NULL);

	if (m_hDirectory == INVALID_HANDLE_VALUE)
	{
		AfxMessageBox(_T("Failed to open directory for monitoring"));
		return ERROR_INVALID_ACCESS;
	}

	char buffer[1024];
	DWORD bytesReturned;
	FILE_NOTIFY_INFORMATION* pNotify;
	CString fileName;
	CString strMsg;

	//파일 변경 탐지 필터 : 모두
	DWORD dwNotifyFilter = FILE_NOTIFY_CHANGE_FILE_NAME | FILE_NOTIFY_CHANGE_DIR_NAME | FILE_NOTIFY_CHANGE_ATTRIBUTES | FILE_NOTIFY_CHANGE_SIZE | FILE_NOTIFY_CHANGE_LAST_WRITE | FILE_NOTIFY_CHANGE_SECURITY;

	do
	{
		if (ReadDirectoryChangesW(
			m_hDirectory,
			&buffer,
			sizeof(buffer),
			TRUE,
			dwNotifyFilter,
			&bytesReturned,
			NULL,
			NULL))
		{
			pNotify = (FILE_NOTIFY_INFORMATION*)buffer;

			do
			{
				fileName = CString(pNotify->FileName, pNotify->FileNameLength / sizeof(WCHAR));
				
				//strMsg.Format(_T("%#x / %s"), pNotify->Action, fileName);
				//AfxMessageBox(strMsg);

				switch (pNotify->Action)
				{
				case FILE_ACTION_ADDED:
					LogHandler(LOG_TYPE_USER_ERROR, Status, __WFILE__, __LINE__, L"File: %s", fileName);
					
					Status = pFolderMonitorDlg->SearchDocs(fileName, pFolderMonitorDlg->m_bOut_Web);
					
					LogHandler(LOG_TYPE_USER_ERROR, Status, __WFILE__, __LINE__, L"SearchDocs: %s", fileName);
					Sleep(100);
					//AfxMessageBox(_T("File added: ") + fileName);
					break;
				case FILE_ACTION_REMOVED:
					//AfxMessageBox(_T("File removed: ") + fileName);
					break;
				case FILE_ACTION_MODIFIED:
					//AfxMessageBox(_T("File modified: ") + fileName);
					break;
				case FILE_ACTION_RENAMED_OLD_NAME:
					//AfxMessageBox(_T("File renamed from: ") + fileName);
					break;
				case FILE_ACTION_RENAMED_NEW_NAME:
					//AfxMessageBox(_T("File renamed to: ") + fileName);
					break;
				}
				
				pNotify = pNotify->NextEntryOffset
					? (FILE_NOTIFY_INFORMATION*)((LPBYTE)pNotify + pNotify->NextEntryOffset)
					: NULL;

			} while (pNotify && !m_stopMonitoring);
		}
		else
		{
			AfxMessageBox(_T("ReadDirectoryChangesW failed"));
			break;
		}

	} while (!m_stopMonitoring);

	CloseHandle(m_hDirectory);
	m_hDirectory = INVALID_HANDLE_VALUE;

	return 0;
}

DWORD 
StartMonitoringFileThread()
{
	DWORD Status = ERROR_SUCCESS;
	DWORD BytesReturned = 0;
	DWORD dwThreadId;

	m_stopMonitoring = FALSE;
	hMonitroingFileThread = NULL;
	hMonitroingFileThread = CreateThread(NULL, 0, MonitroingFileThread, AfxGetMainWnd(), 0, &dwThreadId);

	if(hMonitroingFileThread == NULL)
	{
		Status = GetLastError();
		return Status;
	}

	return Status;
}

DWORD 
StopMonitoringFileThread()
{
	DWORD Status = ERROR_SUCCESS;

	m_stopMonitoring = TRUE;

	if(hMonitroingFileThread)
	{
		WaitForSingleObject(hMonitroingFileThread, INFINITE);
		CloseHandle(hMonitroingFileThread);
		hMonitroingFileThread = NULL;
	}

	if (m_hDirectory != INVALID_HANDLE_VALUE)
	{
		CloseHandle(m_hDirectory);
		m_hDirectory = INVALID_HANDLE_VALUE;
	}

	return Status;
}

void ConvertPath(IN OUT CString& strVal)
{
	strVal.Replace(_T("~$"), _T(""));
}

void CwebtestDlg::OnBnClickedStartBtn()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	DWORD Status = ERROR_SUCCESS;
	CString strMsg = _T(""); CString strTitle = _T("");

	UpdateData(TRUE);

	if(m_strServerIP.IsEmpty() == TRUE || m_strServerPort.IsEmpty() == TRUE)
	{
		AfxMessageBox(_T("서버 IP/PORT를 입력해 주세요."));
		return;
	}

	if(m_strESIndexName.IsEmpty() == TRUE)
	{
		AfxMessageBox(_T("ES 인덱스명을 입력해 주세요."));
		return;
	}

	if(m_FolderPath.IsEmpty() == TRUE)
	{
		AfxMessageBox(_T("모니터링할 폴더를 지정해 주십시오."));
		return;
	}

	if(m_GroupFolderPath.IsEmpty() == FALSE)
	{
		// 분류폴더 enum 해서 폴더, 파일명 얻어옴.
		FileList.RemoveAll();
		Status = GetDirectoryFileList(m_GroupFolderPath.GetBuffer(0), &FileList);
		if(Status != ERROR_SUCCESS) // 에러이면 로그 남김...
		{
			AfxMessageBox(_T("분류폴더목록 얻기 실패"));

			LogHandler(LOG_TYPE_USER_ERROR, Status, __WFILE__, __LINE__, L"GetDirectoryFileList is Fail!!=>GroupFolderPath: %s", m_GroupFolderPath);
			return;
		}
	}

	Status = StartMonitoringFileThread();
	if(Status != ERROR_SUCCESS)
	{
		strMsg.Format(_T("모니터링 시작 실패!!\nerror:%d"), Status);
		AfxMessageBox(strMsg);
	}

	// 리스트에 뿌려줌
	if(m_bOut_Web==TRUE)
	{
		strTitle.Format(_T("*1.검색 테스트시작==>%s:%s"), m_strServerIP, m_strServerPort);
	}
	else
	{
		strTitle.Format(_T("*2.분류 테스트시작==>%s:%s"), m_strServerIP, m_strServerPort);
	}
	
	int nSearch_Method = 1;		// 하이브리드 검색=백터+BM25

	if(_wcsicmp(m_strSearchMethod, _T("벡터")) == 0)
	{
		nSearch_Method=0;
	}
	else if(_wcsicmp(m_strSearchMethod, _T("BM25")) == 0)
	{
		nSearch_Method=2;
	}

	strMsg.Format(_T("*인덱스: %s, *검색방식/수:%s(%d)/%s"), m_strESIndexName, m_strSearchMethod, nSearch_Method, m_strSearchK);
	// 리스트에 추가...
	InsertList(strTitle, strMsg, _T(""), _T(""));
}


void CwebtestDlg::OnBnClickedStopBtn()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	DWORD Status = ERROR_SUCCESS;
	CString strMsg = _T("");

	Status = StopMonitoringFileThread();
	if(Status != ERROR_SUCCESS)
	{
		strMsg.Format(_T("모니터링 중지 실패!!\nerror:%d"), Status);
		AfxMessageBox(strMsg);
	}
}

void CwebtestDlg::InsertList(CString strText1, CString strText2, CString strText3, CString strText4)
{
	// 리스트에 뿌려줌
	ULONG CurrentListIndex = m_MonitorViewList.GetItemCount();
	CString strIndex = _T("");
	strIndex.Format(_T("%d"), CurrentListIndex+1);

	InsertItemInList(&m_MonitorViewList, CurrentListIndex, 0, strIndex.GetBuffer(0));		// no(순번 표기)
	InsertItemInList(&m_MonitorViewList, CurrentListIndex, 1, strText1.GetBuffer(0));// 파일명
	InsertItemInList(&m_MonitorViewList, CurrentListIndex, 2, strText2.GetBuffer(0));				// 분류폴더명
	InsertItemInList(&m_MonitorViewList, CurrentListIndex, 3, strText3.GetBuffer(0));		// 스코어
	InsertItemInList(&m_MonitorViewList, CurrentListIndex, 4, strText4.GetBuffer(0));	// 처리시간
}

DWORD 
CwebtestDlg::SearchDocs(IN CString strFilePath, // 파일경로
						IN int nOut_Web			// 0=검색결과만 json으로 리턴, 1=웹으로 요약, 검색결과등을 html로 리턴
						)
{

	DWORD Status = ERROR_SUCCESS;
	CString strFileFullPath = _T("");
	CString strMsg = _T("");
	CString strText1 = _T(""); CString strText2 = _T("");
	
	if(m_strServerIP.IsEmpty() == TRUE || m_strServerPort.IsEmpty() == TRUE)
	{
		AfxMessageBox(_T("서버 IP/PORT를 입력해 주세요."));
		return ERROR_INVALID_PARAMETER;
	}

	if(m_strESIndexName.IsEmpty() == TRUE)
	{
		AfxMessageBox(_T("ES 인덱스명을 입력해 주세요."));
		return ERROR_INVALID_PARAMETER;
	}

	// 임시파일 ~$ 앞에 문자 제거해서 원본 파일명 얻어옴.
	ConvertPath(strFilePath);	
	strFileFullPath.Format(_T("%s\\%s"), m_FolderPath, strFilePath);

	LARGE_INTEGER start, end, frequency;
	double elapsedTime;
	// 고해상도 타이머의 주파수를 가져옴
	QueryPerformanceFrequency(&frequency);
	// 함수 호출 전 시간 측정 시작
	QueryPerformanceCounter(&start);

	//CString strIp = _T("10.10.4.10");
	//CString strPort = _T("9003");
	//CString strFilePath = _T("D:\\새롬정보시스템_회의.txt");
	//CString strIndexName = _T("mpower10u_vector");

	int nSearch_k = _ttoi(m_strSearchK);
	int nSearch_Method = 1;

	if(_wcsicmp(m_strSearchMethod, _T("벡터")) == 0)
	{
		nSearch_Method=0;
	}
	else if(_wcsicmp(m_strSearchMethod, _T("BM25")) == 0)
	{
		nSearch_Method=2;
	}
	
	// URL 데이터 만듬.

	// 폴더 path만 URL인코딩 한후, URLData 만듬
	CString strURLEncodeGroupFolderPath = _T("");
	strURLEncodeGroupFolderPath.Format(_T("%s"), m_GroupFolderPath);

	CString strUrlData = _T("");
	strUrlData.Format(_T("/upload/es/%s/search?search_k=%d&search_method=%d&out_web=%d&local_folder_path=%s"), 
		m_strESIndexName, nSearch_k, nSearch_Method, nOut_Web, URLEncode(strURLEncodeGroupFolderPath));

	strMsg.Format(_T("FilePath: %s, URLData: %s"), strFileFullPath, strUrlData);
	LogHandler(LOG_TYPE_USER_ERROR, Status, __WFILE__, __LINE__, L"%s", strMsg);

	// 리스트에 추가...
	strText1.Format(_T("*문서임베딩시작: %s"), strFileFullPath);
	strText2.Format(_T("*IP: %s:%s"), m_strServerIP, m_strServerPort);
	InsertList(strText1, strText2, _T(""), _T(""));

	CStringW strResponseW = _T("");

	ProgressShow(strFilePath, L"문서 임베딩 처리중...");

	Status = FileSend(m_strServerIP, _ttoi(m_strServerPort), strUrlData, strFileFullPath, strResponseW);
	ProgressHide();

	if(Status != ERROR_SUCCESS)
	{
		MessageBox(strResponseW, TITLE_TEXT, MB_ICONSTOP | MB_OK);
		return Status;
	}
	
	// 리스트에 추가...
	strText1.Format(_T("*문서임베딩종료: %s"), strFileFullPath);
	strText2.Format(_T("*에러: %d"), Status);
	InsertList(strText1, strText2, _T(""), _T(""));

	// 리스트에 추가...
	strText1.Format(_T("*검색시작: %s"), strFileFullPath);
	strText2.Format(_T("*URLData: %d"), strUrlData);
	InsertList(strText1, strText2, _T(""), _T(""));

	if(Status == ERROR_SUCCESS)
	{
		ProgressShow(strFilePath, L"문서 검색 결과 출력중...");

		if(nOut_Web == 1)
		{
			// HTML 파일을 기본 웹 브라우저로 열기
			OpenHtmlInBrowser(strResponseW);
		}
		// json 파싱하여 보여줌.
		else
		{
			UINT nNum = 0;// 목록 계수
			Status = Parse_List01(strResponseW,	nNum, &m_SimilarDocDataList);			
			if(Status==ERROR_SUCCESS)
			{
				// 최대 Score를 갖는 폴더와 score 구함.
				WCHAR MaxFolderPath[MAX_PATH] = { 0 };	//최대값 폴더명
				DOUBLE MaxScore = 0.0;					//최대값 폴더명 스코어

				Status = GetMaxScoreClassFolderPath(strFilePath,		// 검색할 파일명
					strFileFullPath,									// 검색할 파일경로
					&FileList,											// 분류파일목록
					&m_SimilarDocDataList,								// 검색된 유사목록
					&FolderList,										// 폴더목록
					MaxFolderPath,									// 최대스코어를 가지는 폴더
					MaxScore);											// 최대스코어

				// 함수 호출 후 시간 측정 종료
				QueryPerformanceCounter(&end);
				elapsedTime = static_cast<double>(end.QuadPart - start.QuadPart) / frequency.QuadPart;// 경과된 시간 계산 (초 단위)

				if(Status == ERROR_SUCCESS)
				{
					// 리스트에 추가...
					CString strScore = _T(""); CString strTimesecond = _T("");
					strScore.Format(_T("%.2f"), MaxScore);
					strTimesecond.Format(_T("%.2f초"), elapsedTime);
					InsertList(strFileFullPath, MaxFolderPath, strScore, strTimesecond);

					//strMsg.Format(_T("\r\n%s => %s\r\n*스코어: %.3f\r\n*경과시간: %.3f"), strFileFullPath, MaxFileFullPath, MaxScore, elapsedTime);
					//MessageBox(strMsg, _T("파일분류성공"), MB_ICONINFORMATION);
				}
				else
				{
					ProgressHide();
					strMsg.Format(_T("에러: %d\r\n*경과시간: %.3f"), Status, elapsedTime);
					::MessageBox(NULL, strMsg, _T("파일분류실패!!"), MB_ICONINFORMATION);
				}
			}
		}	

		ProgressHide();
	}
	else
	{
		//AfxMessageBox(strResponseW);
		LogHandler(LOG_TYPE_USER_ERROR, Status, __WFILE__, __LINE__, L"%s", strResponseW);
		return Status;
	}

	return Status;
}

void CwebtestDlg::OnClose()
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	DeleteCriticalSection(&WriteLogLock);

	// 프로그래스 바 제거
	ProgressDestroy();

	CDialogEx::OnClose();
}


void CwebtestDlg::OnBnClickedOutWebCheck()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	UpdateData(TRUE);

}

// 분류폴더
void CwebtestDlg::OnBnClickedFolderSelectBtn2()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	DWORD Status = ERROR_SUCCESS;
	CString strMsg = _T("");

	BROWSEINFO BrowseInfo;
	LPITEMIDLIST pItemIdList = NULL;
	
	//'컴퓨터' 의 IDLIST 얻기
	LPITEMIDLIST pComputerIdList = NULL;
	SHGetSpecialFolderLocation(NULL, CSIDL_DRIVES , &pComputerIdList);
	WCHAR LocalVirtualDiskRegionPath[MAX_PATH] = {0,};

	ZeroMemory(&BrowseInfo, sizeof(BROWSEINFO));
	BrowseInfo.hwndOwner = NULL; //m_hWnd;
	BrowseInfo.pidlRoot = pComputerIdList;
	BrowseInfo.pszDisplayName = LocalVirtualDiskRegionPath;
	BrowseInfo.lpszTitle = _T("모니터링할 폴더를 지정해 주십시오.");
	BrowseInfo.ulFlags = BIF_NEWDIALOGSTYLE;
	BrowseInfo.lpfn = BrowseCallbackProc;
	BrowseInfo.lParam = (LPARAM)(LPTSTR)(LPCTSTR)m_FolderPath;

	pItemIdList = ::SHBrowseForFolder(&BrowseInfo);
	if(pItemIdList == NULL)
	{
		if(pComputerIdList != NULL)CoTaskMemFree(pComputerIdList);
		return;
	}

	if(pComputerIdList != NULL)CoTaskMemFree(pComputerIdList);

	SHGetPathFromIDList(pItemIdList, LocalVirtualDiskRegionPath);

	m_GroupFolderPath = LocalVirtualDiskRegionPath;

	// [bong][2019-11-06] 끝에 \ 가 있으면 삭제
	if(m_GroupFolderPath[m_GroupFolderPath.GetLength() - 1] == '\\')
	{
		m_GroupFolderPath.SetAt(m_GroupFolderPath.GetLength() - 1, '\0');
	}

	UpdateData(FALSE);

	// 분류폴더 enum 해서 폴더, 파일명 얻어옴.
	FileList.RemoveAll();
	Status = GetDirectoryFileList(m_GroupFolderPath.GetBuffer(0), &FileList);
	if(Status != ERROR_SUCCESS) // 에러이면 로그 남김...
	{
		LogHandler(LOG_TYPE_USER_ERROR, Status, __WFILE__, __LINE__, L"GetDirectoryFileList is Fail!!=>GroupFolderPath: %s", m_GroupFolderPath);
		return;
	}

	/*
	CString strFileName = _T("");
	WCHAR FolderPath[MAX_PATH] = {0, };
	Status = SearchFileList(strFileName.GetBuffer(0), &FileList, FolderPath);
	if(Status != ERROR_SUCCESS) // 에러이면 로그 남김...
	{
		LogHandler(LOG_TYPE_USER_ERROR, Status, __WFILE__, __LINE__, L"SearchFileList is Fail!!=>strFileName: %s", strFileName);
		return;
	}
	*/
}


void CwebtestDlg::OnBnClickedInitListBtn()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	m_MonitorViewList.DeleteAllItems();
}
